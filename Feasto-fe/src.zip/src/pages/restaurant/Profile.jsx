import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  Utensils, 
  MapPin, 
  Star, 
  Plus, 
  Settings, 
  ShoppingBag, 
  Trash2, 
  Edit3 
} from 'lucide-react';

const API_BASE_URL = "http://localhost:8080/restaurants";

const RestaurantProfile = ({ restaurantId = 1 }) => {
  const [restaurant, setRestaurant] = useState(null);
  const [menuItems, setMenuItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('menu'); // 'menu' or 'orders'

  // 1. Fetch Restaurant Details & Menu
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [resDetails, resMenu] = await Promise.all([
          axios.get(`${API_BASE_URL}/${restaurantId}`),
          axios.get(`${API_BASE_URL}/${restaurantId}/menu`)
        ]);
        setRestaurant(resDetails.data);
        setMenuItems(resMenu.data);
      } catch (error) {
        console.error("Error fetching restaurant data:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [restaurantId]);

  // 2. Handle Menu Item Deletion
  const handleDeleteItem = async (menuItemId) => {
    if (window.confirm("Are you sure you want to delete this item?")) {
      try {
        await axios.delete(`${API_BASE_URL}/${restaurantId}/menu/${menuItemId}`);
        setMenuItems(menuItems.filter(item => item.id !== menuItemId));
      } catch (error) {
        alert("Failed to delete item");
      }
    }
  };

  if (loading) return <div className="flex h-screen items-center justify-center">Loading...</div>;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header / Hero Section */}
      <div className="relative h-64 bg-orange-600 text-white">
        <div className="container mx-auto px-6 py-12">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center overflow-hidden border-4 border-white shadow-lg">
              {restaurant?.imageUrl ? (
                <img src={restaurant.imageUrl} alt="logo" className="w-full h-full object-cover" />
              ) : (
                <Utensils className="text-orange-600 w-16 h-16" />
              )}
            </div>
            <div className="text-center md:text-left">
              <h1 className="text-4xl font-bold">{restaurant?.name || 'Restaurant Name'}</h1>
              <div className="flex items-center gap-4 mt-2 text-orange-100">
                <span className="flex items-center gap-1"><MapPin size={16}/> {restaurant?.city}</span>
                <span className="flex items-center gap-1"><Star size={16}/> {restaurant?.rating || 'New'}</span>
              </div>
            </div>
            <button className="md:ml-auto bg-white text-orange-600 px-6 py-2 rounded-lg font-semibold flex items-center gap-2 hover:bg-orange-50 transition">
              <Settings size={18}/> Edit Profile
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-6 py-8">
        <div className="flex gap-8 border-b mb-8 text-lg font-medium">
          <button 
            onClick={() => setActiveTab('menu')}
            className={`pb-4 px-2 ${activeTab === 'menu' ? 'border-b-2 border-orange-600 text-orange-600' : 'text-gray-500'}`}
          >
            Menu Items
          </button>
          <button 
            onClick={() => setActiveTab('orders')}
            className={`pb-4 px-2 ${activeTab === 'orders' ? 'border-b-2 border-orange-600 text-orange-600' : 'text-gray-500'}`}
          >
            Live Orders
          </button>
        </div>

        {activeTab === 'menu' ? (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-800">Manage Menu</h2>
              <button className="bg-orange-600 text-white px-4 py-2 rounded-md flex items-center gap-2 hover:bg-orange-700">
                <Plus size={20}/> Add New Item
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {menuItems.map((item) => (
                <div key={item.id} className="bg-white rounded-xl shadow-sm border p-4 flex gap-4 group">
                  <div className="w-24 h-24 bg-gray-100 rounded-lg flex-shrink-0 overflow-hidden">
                    <img src={item.imageUrl || 'https://via.placeholder.com/150'} alt={item.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-grow">
                    <div className="flex justify-between">
                      <h3 className="font-bold text-gray-800">{item.name}</h3>
                      <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition">
                        <button className="text-blue-500 hover:text-blue-700"><Edit3 size={16}/></button>
                        <button 
                          onClick={() => handleDeleteItem(item.id)}
                          className="text-red-500 hover:text-red-700"
                        ><Trash2 size={16}/></button>
                      </div>
                    </div>
                    <p className="text-sm text-gray-500 line-clamp-2 mt-1">{item.description}</p>
                    <p className="text-orange-600 font-bold mt-2">${item.price}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow-sm p-12 text-center">
            <ShoppingBag className="mx-auto text-gray-300 w-16 h-16 mb-4" />
            <h3 className="text-xl font-medium text-gray-600">Order Management coming soon</h3>
            <p className="text-gray-400">Switch to the Menu tab to manage your dishes.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default RestaurantProfile;